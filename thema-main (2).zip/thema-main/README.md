# Theme
JANGAN DIJUAL BELAKAN YE BWANG !!!
BUTUH LICENSE/PW CHAT WA GUA
>> wa.me/6283163553339  <<

Comand Run Install Thema

bash <(curl https://raw.githubusercontent.com/lydiaaxxxz/thema/main/install.sh)
