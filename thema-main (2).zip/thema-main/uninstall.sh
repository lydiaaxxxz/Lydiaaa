


# Membuat lokasi baru
bash <(curl -s https://pterodactyl-installer.se) <<EOF
y
y
y
y
EOF

echo "Proses Uninstall Panel Selesai."
